<?php
session_start();
if(empty($_SESSION['email']))
{
	header('location:login.php');
}

echo $e=$_SESSION['email'];

if(isset($_POST['changepic']))
{  
   $con=mysqli_connect('localhost','root','','project1');

	$a=$_FILES['pic']; //this is array that stores all the things about image into it
	//print_r($a); //to print the real value stored inside the variable
	echo $x=$a['name'];
	$r=move_uploaded_file($a['tmp_name'], 'image/'.$x);
	$p="image/".$x;
	if($r){
		$u="update student set profilepic='$p' where email='$e'";
		$re=mysqli_query($con,$u);
		if($re){
			echo "Updated";
		}
	}
   
}

?>
<body>
<form action="resetimage.php" method="post" enctype="multipart/form-data">
<input type="file" name="pic">
<input type="submit" name="changepic">

</form>
</body>
