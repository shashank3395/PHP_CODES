<?php
session_start();
if(!empty($_SESSION['email']))
{
$x=$_SESSION['email'];
if(isset($_POST['submit']))
{
$a=$_POST['email'];
$b=$_POST['password'];
$con=mysqli_connect('localhost','root','','project1');
$q="update student set password='$b' where email='$x'";
$r=mysqli_query($con,$q);
if($r)
{
	echo "<script>alert('PASSWORD RESET SUCCESSFULL');</script> ";
	sleep(2);
	session_destroy();
	header("location:login.php");
}
}
}
else{
	echo "<script>alert('ILLEGAL ACCESS!!')";
	session_destroy();
	header('location:login.php');
}
?>
<style>
.design{
		background-image: url("back3.jpg");
		height: 400px;
		width:300px;
		border-style: double;
		border-width: 10px;
		
	}
	   .button {
  padding: 10px 17px;
  font-size: 13px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #10DF50;
  border: none;
  border-radius: 7px;
  box-shadow: 0 5px #999;
}
.button:hover {background-color: #3e8e41}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 3px #666;
  transform: translateY(4px);
}


</style>
<body background="log.jpg">

<center>
	<font face="boston traffic" color="black" size="24" >RESET PASSWORD</font><br>
	<br>
	<br>

	<form action="reset.php" method="post" class="design">
	<br><br><img src="login.jpg" width="200" height="200" border="5">
	
	<br><font face="" color="blue"><input type="hidden" name="email" value="<?php echo $x?>"></br>
	Enter new password <input type="text" name="password"><br></font>
	<br>
	<br>
	<input type="submit" name="submit" class="button">
</form></center>
</body>