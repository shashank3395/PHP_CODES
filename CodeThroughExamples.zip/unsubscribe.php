<?php

if(isset($_POST['unsubscribe']))
{$e=$_POST['email'];
 $con=mysqli_connect('localhost','root','','project1');
	$q="select *from subscribers where email='$e'";
	$r=mysqli_query($con,$q);
   $num=mysqli_num_rows($r);
	if($num>0)
	{
		$qw="select *from subscribers where email='$e' and status='active'";
		$rest=mysqli_query($con,$qw);
		$nu=mysqli_num_rows($rest);
		if($nu>0)
		{
			$qwe="update subscribers set status='inactive' where email='$e'";
			$resu=mysqli_query($con,$qwe);
			echo "<script>alert('unsubscribed successfully!!');</script>";
			
			
		}
		else
		{
			echo "<script>echo('you are allreary unsubscribed!!!');</script>";
		}
	}

else{
	echo "<script>alert('You are not subscribed yet');</script>";
	
	
}
}

?>
<form action="unsubscribe.php" method="post">
	
	Enter Email:<input type="text" name="email">
     <input type="submit" name="unsubscribe">
</form>
