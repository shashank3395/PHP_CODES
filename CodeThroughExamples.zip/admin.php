<?php 
$con=mysqli_connect('localhost','root','','project1');
$q="select * from student";
$r=mysqli_query($con,$q) or die(mysqli_error($r));
$total_record=mysqli_num_rows($r);
$per_page=4;
$total_pages=ceil($total_record/$total_record);
if(isset($_REQUEST['page']))
{
	$p=$_REQUEST['page'];
	$ind=($p-1)*per_page;
	$sn=$ind_1;//to allot the serial no
}
else
{
	$ind=0;
	$sn=1;
}
$qry="select * from student limit $ind,$per_page";
$result=mysqli_query($con,$query);

echo "<table>
      <tr><th>$sn

?>



























