<?php

session_start();
if(empty($_SESSION['email']))
{
	header('location:login.php');
}
else
{  
  if(isset($_POST['change']))
  {$p=$_POST['old'];
   $n=$_POST['new'];
  
	$s=$_SESSION['email'];
		$con=mysqli_connect('localhost','root','','project1');

         
         $q=("select *from student where email='$s' && password='$p'");
          $res=mysqli_query($con,$q) or die(mysqli_error($res));
          if($res)
         {  
             $l=("update student set password='$n' where email='$s'");
             $rest=mysqli_query($con,$l);

             if($rest)
            {echo "<script>alert('Password Changed Successfully!!!');</script>";
               sleep(2);
            
            }  
            else
            {
            	echo "<script>alert('Password not changed');</script>";
            }
         }
         else
         {
         	echo "<script>alert('Incorrect Previous Password!!!!');</script>";
         }

}
}




?>
<body>
	<form method="post" action="changepassword.php">
		Old Password :<input type="text" name="old"><br>
		New Password :<input type="password" name="new"><br>
        <input type="submit" name="change" value="Change Password">
    </form>
</body>