<?php

//to restrict the illege; acces to any profile
session_start();
if(empty($_SESSION['email']))
{
header('location:login.php');
}
//this is all about the data to be carried to next page



/*$q="select *from student";
$res=mysqli_query($con,$q);

$n=mysqli_num_rows($res);
$arr=array();
if($n>0)
{
	while($ar=mysqli_fetch_assoc($res)){
		//echo "<pre>";
		//print_r($ar);
		$arr[]=$ar;
	}
	}
	else
		echo "record not found";
}*/

else
{     
   if(isset($_POST['change']))
    {    
   
         header("location:resetimage.php");
    }


	if(isset($_POST['logout']))
	{
		session_destroy();
         header('location:login.php');
	}
	if(isset($_POST['deleteprofile']))
	{  
		$s=$_SESSION['email'];
		$con=mysqli_connect('localhost','root','','project1');

         
         $q=("Update student set status='inactive' where email='$s'");
          $res=mysqli_query($con,$q);
          if($res)
            {echo "<script>alert('Account Deleted');</script>";
            sleep(3);
              session_destroy();
              header('location:login.php');
            }
           else{
     	    echo "<script>alert('account cannot be deleted');</script>";
              }
	}


	if(isset($_POST['changepassword']))
	{
		header('location:changepassword.php');
	}
        


	$con=mysqli_connect('localhost','root','','project1');
   //this line was to be included if the email id was to be taken through quer string
   $t=$_SESSION['email'];
   $q="select * from student where email='$t'";
   $arr=array();
   $res=mysqli_query($con,$q);
   $n=mysqli_num_rows($res);
   }

 

?>

<style>
	.design{
		background-image: url("back5.jpg");
		height: 1000px;
		width:600px;
		border-style: double;
		border-width: 10px;
		
	}
	.table{
		font-size: 20px;
		font-family: "algerian";
	}
	   .button {
  padding: 10px 17px;
  font-size: 13px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #15ff40;
  border: none;
  border-radius: 7px;
  box-shadow: 0 5px #999;
}
.button:hover {background-color: #101041}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 3px #666;
  transform: translateY(4px);
}
</style>

<!DOCTYPE html>
<html>
<body background="back6.jpg">
	
		<!--<tr>
			<th>Id</th>
             <th>Name</th>
             <th>Email</th>
             <th>Address</th>
			</tr>-->
			<?php
			    $arr[]=mysqli_fetch_assoc($res);
			    ?>
			<center><div class="design"><img src="<?php echo $arr[0]['profilepic']; ?>" height=225 width=175 border=6 border-color=green>
				<form action="profile.php" method="post">
				
				<input type="submit" name="change" class="button" value="Update pic"><br><hr><br>
				</form>
				<?php
				var_dump($arr);
			foreach($arr as $x=>$y)
			{
				echo "<center><div class='table'>";
				foreach($y as $p=>$q)
				{
					if(strcmp($p,'profilepic')==0||strcmp($p,'id')==0)
						continue;
					echo "$p  : $q  <br><br>";
				
				    
				}
				
				echo "</div></center>";
				
			}

			?>
		<form method="post" action="profile.php">
		<input type="submit" name="logout" value="LOGOUT" class="button">
		<input type="submit" name="deleteprofile" value="deleteprofile" class="button">
		<input type="submit" name="changepassword" class="button" value="ChangePassword"></form></div></center>
		
</body>
</html>