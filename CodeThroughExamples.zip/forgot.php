<?php
if(isset($_POST['change']))
{
	$a=$_POST['email'];
	$b=$_POST['ques'];
	$c=$_POST['ans'];
	$con=mysqli_connect('localhost','root','','project1');
	$q="select *from student where email='$a' && ques='$b' && ans='$c'";
	$res=mysqli_query($con,$q);
	$n=mysqli_num_rows($res);
	if($n==0)
	{
		echo "<script> alert('incorrect details');</script>";

	}
	else
	{   session_start();
		$_SESSION['email']=$a;
		header("location:reset.php");
	}
}



?>

<!DOCTYPE>
<HTML>
<BODY>

	<form action="forgot.php" method="post">
		ENTER the email id:<input type="text" name="email"><br>
		Select the security question:<select name="ques">
  <option>select question</option>
  <option>best movie</option>
  <option>best place to visit</option>
</select>
<br>
enter ans:<input type="text" name="ans"><br>
<input type="submit" name="change" value="make changes"></form>
</BODY>
</HTML>