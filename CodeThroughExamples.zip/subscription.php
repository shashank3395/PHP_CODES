<?php
if(isset($_POST['subscribe']))
{
	$e=$_POST['email'];
	$con=mysqli_connect('localhost','root','','project1');
	
	$q=("select *from subscribers where email='$e' and status='active'");
	$res=mysqli_query($con,$q);
    $f=mysqli_num_rows($res);
	if($f>0)
	{
      echo "<script>alert('Allready Subcribed !!!');</script>";
	}
	else
	{   
		$w=("select *from subscribers where email='$e' and status='inactive'");
		$rest=mysqli_query($con,$w);
		$y=mysqli_num_rows($rest);
        if($y>0)
        {
           $ree=("update subscribers set status='active'");
           $rq=mysqli_query($con,$ree);
           if($rq)
           	echo "<script>alert('Subscribed Successfully!!!');</script>";
        }
        else
        {  
        	$w="insert into subscribers(email) values('$e')";
        	$d=mysqli_query($con,$w);
        	if($d)
        	echo "<script>alert('Subscribed Successfully!!!');</script>";
        }
	}

}

?>
<form action="subscription.php" method="post">
	Enter Email:<input type="text" name="email">
	
     <input type="submit" name="subscribe">
</form>