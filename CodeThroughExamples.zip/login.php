
<style type="text/css">
    .alert {
    padding: 20px;
    background-color: #f44336; /* Red */
    color: white;
    margin-bottom: 15px;
}
</style>
<?php

if(isset($_POST['Forgot']))
  header("location:forgot.php");
if(isset($_POST['signup']))
	header('location:registration.php');
if(isset($_POST['subscribe']))
  header('location:subscription.php');
if(isset($_POST['unsubscribe']))
  header('location:unsubscribe.php');
if(isset($_POST['login']))
{
	$a=$_POST['email'];
    $b=$_POST['password'];

	$con=mysqli_connect('localhost','root','','project1');
    $q="select * from student where email='$a' && password='$b' && status='active'";
    $res=mysqli_query($con,$q);
    if($res==true)
    {   $r=mysqli_num_rows($res);
    	if($r==1)
    	{   
         //echo "RECORD FOUND";
    		//starting a session to restrict the illegal login to any profile
              session_start();
            $_SESSION['email']=$a;
            //sending the email information to the next page through cookie
        //setcookie('username',$a,time()+600);
        //redirection to profile.php through query string
            //header("location:profile.php");
            //if we were sending the information through query string
         // header("location:profile.php?v=$a");
            header("location:profile.php");
    	}

    	
    	else { 
            ?>
            <div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  WRONG Email/Password!!!
</div>
    		<?php
        }

    }
    else
        echo "wrong syntex";
}




?>
<!DOCTYPE html>
<html>
<body background="back5.jpg">
    <style>
    .square{
    width: 300px;
    height: 600px;
    background-image: url("log.jpg");
    border-style: inset;
    border-width: large;
    border-color: red;
    
    }
    .button {
  padding: 10px 17px;
  font-size: 13px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #10DF50;
  border: none;
  border-radius: 7px;
  box-shadow: 0 5px #999;
}
.button:hover {background-color: #3e8e41}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 3px #666;
  transform: translateY(4px);
}
/* Your Color */
</style>

<u><font face="boston traffic" color="blue" size="80"><center>STUDENT LOGIN</center></font></u>
<center><div class='square' align="center">
<div align="center"><img src="icon.png" width=270px height=270px></div>
    <form method="post" action="login.php">
	<br>
    <br><div style="font-family: comic sans MS;font-size: 20px;"> 
      Email Id &nbsp: <input type="text" name="email" required="mendatory" ><br><br>
	&nbsp Password : <input type="password" name="password" height=20px required="mendatory"><br>

</font><br><br></div>
    <input type="submit" name="login" value="LOGIN" class="button"> &nbsp &nbsp
    </form>
    <form action="login.php" method="post"><input type="submit" name="signup" value="SIGN UP" class="button">
    <input type="submit" name="Forgot" value="forgot" class="button">
    <input type="submit" name="subscribe" value="Subscribe Now">
    <input type="submit" name="unsubscribe" value="Unsubscribe Now">
	
</form></div>
</center>
</body>
</html>