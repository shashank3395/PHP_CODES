<?php

//redirection to login.php if we click on login button
if(isset($_POST['login']))
{
	header('location:login.php');
}


//to run the regestration procedure if we once click the register button
if(isset($_POST['registration']))
{
$a=$_POST['name'];
$b=$_POST['email'];
$c=$_POST['password'];
$d=$_POST['contact'];
$e=$_POST['room'];
$f=$_POST['course'];
$g=$_POST['branch'];
$h=$_POST['address'];
$v=$_POST['ques'];
$u=$_POST['ans'];

//to eastablish the connection bw the server
$con=mysqli_connect('localhost','root','','project1');//to show exact error
//to check if the email you entered is valid
$q="select *from student where email='$b'";
$resu=mysqli_query($con,$q);
$k=mysqli_num_rows($resu);
if($k>0)
{
  echo "<script>alert('Email is already taken by some individual');</script>";

}
else
{

//everything about image
$target_dir="image/";
$target_file = $target_dir.basename($_FILES["filetoupload"]["name"]);
$Uploadok=1;
$imageFileType=strtolower(pathinfo($target_file,PATHINFO_EXTENSION));



//to check whether the image is real or FAKE
$check=getimagesize($_FILES["filetoupload"]["tmp_name"]);
//it is to check the upload activity of info
if($check!==false)
{
  $Uploadok=1;
}
else
{
  $Uploadok=0;
}
if($Uploadok==0)
  echo "<script>alert('Your image was not uploaded');</script>";
else
{
  if(move_uploaded_file($_FILES['filetoupload']['tmp_name'], $target_file))
  {
      echo "<script>alert('Image is uploaded');</script>";
  }
}

//to establish the connection bw database and php

//$con=mysqli_connect('localhost','root','','batch') or die('some error');//to show simple error message
//to show an error so that it is executed furthur in case any error is caused




//query to insert the data into the mysql database
$q="insert into student(name,email,password,contact,room,course,branch,address,ques,ans,profilepic) values('$a','$b','$c','$d','$e','$f','$g','$h','$v','$u','$target_file')";
//query is stored in string datatype
//to run the query

$result=mysqli_query($con,$q);
//to show the error or to make sure if data is inserted then $result is true else $result is false
if($result==true)
echo "<script>alert('Registered successfully');</script>";
else
echo "try again";
}
}
?>
<!DOCTYPE HTML>
<html>

    <style>
    .square{
    width: 400px;
    height: 900px;
    background-image: url("log.jpg");
    border-style: inset;
    border-width: large;
    border-color: red;
    border-width: 10px;
    
    }
    	   .button {
  padding: 10px 17px;
  font-size: 13px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #15ff40;
  border: none;
  border-radius: 7px;
  box-shadow: 0 5px #999;
}
.button:hover {background-color: #101041}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 3px #666;
  transform: translateY(4px);
}/* Your Color */
</style>
<body background="back6.jpg">
<u><font face="boston traffic" color="#19F" size="100" ><center>REGISTRATION FORM</center></font></u>
<hr>
<center><div class='square' style="font-family: comic sans MS;font-size: 20px;">
<form action="registration.php" method="post" enctype="multipart/form-data">
Name :<input type="text" name="name"><br><br>
Email :<input type="text" name="email"><br><br>
Password :</font> <input type="Password" name="password"><br><br>
Contact :<input type="text" name="contact"><br><br>
Room : <input type="text" name="room"><br><br>
Course :<input type="text" name="course"><br><br>
Branch :<input type="text" name="branch"><br><br>
Upload Image: &nbsp<input type="file" name="filetoupload" id="filetoupload"><br>
Address :<textarea name="address"></textarea><br><br>


Select the security question:<select name="ques">
  <option>select question</option>
  <option>best movie</option>
  <option>best place to visit</option>
  <option>best place to visit</option>
</select>
<br>
enter ans:<input type="text" name="ans"><br>
<input type="submit" name="registration" value="REGISTER" class="button">
<input type="reset" name="reset" class="button" value="RESET">
<input type="submit" name="login" value="LOGIN" class="button">
</form></div></center>
</body>
</html>
